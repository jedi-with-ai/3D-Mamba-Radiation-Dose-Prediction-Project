import os
import torch
import numpy as np
from torch.utils.data import DataLoader
from models.unet import MambaUNet3D
from data.dataset import HeadNeckDataset
from utils.visualization import visualize_test_prediction


def test_model_on_test_folder(model_path, test_dir, save_preds=True, device='cuda'):
    test_dataset = HeadNeckDataset(test_dir)
    test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False, num_workers=0)

    model = MambaUNet3D(in_channels=11, out_channels=1, features=[32, 64, 128])
    model.load_state_dict(torch.load(model_path))
    model = model.to(device)
    model.eval()

    os.makedirs('test_pred', exist_ok=True)

    with torch.no_grad():
        for i, batch in enumerate(test_loader):
            inputs, _, _, _, pid = batch
            pid = pid[0]  # unpack string from tuple

            inputs = inputs.to(device)
            outputs = model(inputs)  # shape: (1,1,D,H,W)

            outputs_np = outputs[0, 0].cpu().numpy()

            if save_preds:
                out_path = os.path.join('test_pred', f'{pid}.npy')
                np.save(out_path, outputs_np)
                print(f"Saved prediction for {pid} → {out_path}")

            print(f"[{i+1}/{len(test_loader)}] {pid}: min {outputs_np.min():.4f}, max {outputs_np.max():.4f}")

    print("✅ Test inference completed.")


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Run inference with trained model')
    parser.add_argument('--model_path', type=str, default='best_mamba_model.pth',
                        help='Path to the trained model weights')
    parser.add_argument('--test_dir', type=str, required=True,
                        help='Directory containing test data')
    parser.add_argument('--save_preds', action='store_true', default=True,
                        help='Save predictions to disk')
    parser.add_argument('--visualize', action='store_true',
                        help='Visualize a prediction after inference')
    parser.add_argument('--patient_id', type=str, default=None,
                        help='Patient ID to visualize (required if --visualize is set)')
    parser.add_argument('--slice', type=int, default=64,
                        help='Z-slice to visualize')
    
    args = parser.parse_args()
    
    # Run inference
    test_model_on_test_folder(
        model_path=args.model_path,
        test_dir=args.test_dir,
        save_preds=args.save_preds
    )
    
    # Visualize if requested
    if args.visualize:
        if args.patient_id is None:
            print("Error: --patient_id required for visualization")
        else:
            pred_path = os.path.join('test_pred', f'{args.patient_id}.npy')
            visualize_test_prediction(
                pred_path=pred_path,
                test_dir=args.test_dir,
                z_slice=args.slice
            )