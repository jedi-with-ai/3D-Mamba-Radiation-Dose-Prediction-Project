import os
import torch
import argparse
from data.dataset import HeadNeckDataset
from models.unet import MambaUNet3D
from utils.train import train_model
from utils.visualization import visualize_prediction


def main(args):
    # Create dataset
    dataset = HeadNeckDataset(args.data_dir)

    # Create model
    model = MambaUNet3D(in_channels=11, out_channels=1, 
                        features=[args.features[0], args.features[1], args.features[2]])

    # Print model summary
    total_params = sum(p.numel() for p in model.parameters())
    print(f"Model created with {total_params:,} parameters")

    # Train model
    train_model(model, dataset, 
                batch_size=args.batch_size, 
                epochs=args.epochs, 
                lr=args.learning_rate,
                device=args.device)

    # Visualize results
    try:
        model.load_state_dict(torch.load('best_mamba_model.pth'))
        visualize_prediction(model, dataset, patient_idx=0, z_slice=args.slice, device=args.device)
    except Exception as e:
        print(f"Visualization error: {e}")
        print("Try visualization after training completes")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Train the Mamba UNet 3D model')
    parser.add_argument('--data_dir', type=str, required=True,
                        help='Directory containing the training data')
    parser.add_argument('--batch_size', type=int, default=1,
                        help='Batch size for training')
    parser.add_argument('--epochs', type=int, default=10,
                        help='Number of training epochs')
    parser.add_argument('--learning_rate', type=float, default=3e-4,
                        help='Learning rate for the optimizer')
    parser.add_argument('--features', type=int, nargs=3, default=[32, 64, 128],
                        help='Feature dimensions for each UNet level (3 values required)')
    parser.add_argument('--device', type=str, default='cuda' if torch.cuda.is_available() else 'cpu',
                        help='Device to use for training (cuda/cpu)')
    parser.add_argument('--slice', type=int, default=64,
                        help='Z-slice to visualize in the results')
    
    args = parser.parse_args()
    main(args)