import torch.nn as nn


class MambaBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        # Simplified Mamba-inspired block
        self.conv1 = nn.Conv3d(channels, channels, kernel_size=3, padding=1)
        self.norm1 = nn.InstanceNorm3d(channels)
        self.act1 = nn.LeakyReLU(inplace=True)

        # Depth-wise convolution for local context
        self.dw_conv = nn.Conv3d(
            channels, channels, kernel_size=5, padding=2, groups=channels
        )

        self.conv2 = nn.Conv3d(channels, channels, kernel_size=3, padding=1)
        self.norm2 = nn.InstanceNorm3d(channels)
        self.act2 = nn.LeakyReLU(inplace=True)

    def forward(self, x):
        residual = x

        # First conv block
        x = self.conv1(x)
        x = self.norm1(x)
        x = self.act1(x)

        # Depth-wise conv (Mamba-inspired)
        x = self.dw_conv(x)

        # Second conv block
        x = self.conv2(x)
        x = self.norm2(x)

        # Add residual
        x = x + residual
        x = self.act2(x)

        return x