import torch
import torch.nn as nn
import torch.nn.functional as F


class DVHFocusedLoss(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, pred, target, ptv_mask, oar_mask):
        # Base MSE loss
        mse_loss = F.mse_loss(pred, target)

        # PTV-focused loss (encourage higher doses in target volumes)
        ptv_pred = pred * ptv_mask
        ptv_target = target * ptv_mask
        ptv_voxels = ptv_mask.sum()

        if ptv_voxels > 0:
            # Penalize underdosing in PTV (clinical priority)
            ptv_underdose = F.relu(ptv_target - ptv_pred)
            ptv_loss = 4.0 * (ptv_underdose ** 2).sum() / (ptv_voxels + 1e-8)
        else:
            ptv_loss = 0.0

        # OAR-focused loss (encourage lower doses in organs at risk)
        oar_pred = pred * oar_mask
        oar_target = target * oar_mask
        oar_voxels = oar_mask.sum()

        if oar_voxels > 0:
            # Penalize overdosing in OARs (clinical priority)
            oar_overdose = F.relu(oar_pred - oar_target)
            oar_loss = 3.0 * (oar_overdose ** 2).sum() / (oar_voxels + 1e-8)
        else:
            oar_loss = 0.0

        # Combined loss
        total_loss = mse_loss + ptv_loss + oar_loss
        return total_loss