import torch
import torch.nn as nn
import torch.nn.functional as F
from models.blocks import MambaBlock


class MambaUNet3D(nn.Module):
    def __init__(self, in_channels=11, out_channels=1, features=[32, 64, 128]):
        super().__init__()

        # Input block
        self.inc = nn.Sequential(
            nn.Conv3d(in_channels, features[0], kernel_size=3, padding=1),
            nn.InstanceNorm3d(features[0]),
            nn.LeakyReLU(inplace=True)
        )

        # Encoder blocks
        self.down1 = nn.Sequential(
            nn.MaxPool3d(kernel_size=2, stride=2),
            nn.Conv3d(features[0], features[1], kernel_size=3, padding=1),
            nn.InstanceNorm3d(features[1]),
            nn.LeakyReLU(inplace=True)
        )
        self.mamba1 = MambaBlock(features[1])

        self.down2 = nn.Sequential(
            nn.MaxPool3d(kernel_size=2, stride=2),
            nn.Conv3d(features[1], features[2], kernel_size=3, padding=1),
            nn.InstanceNorm3d(features[2]),
            nn.LeakyReLU(inplace=True)
        )
        self.mamba2 = MambaBlock(features[2])

        # Bottleneck
        self.bottleneck = MambaBlock(features[2])

        # Decoder blocks
        self.up1 = nn.ConvTranspose3d(features[2], features[1], kernel_size=2, stride=2)
        self.up_mamba1 = MambaBlock(features[1] * 2)
        self.conv1 = nn.Sequential(
            nn.Conv3d(features[1] * 2, features[1], kernel_size=3, padding=1),
            nn.InstanceNorm3d(features[1]),
            nn.LeakyReLU(inplace=True)
        )

        self.up2 = nn.ConvTranspose3d(features[1], features[0], kernel_size=2, stride=2)
        self.up_mamba2 = MambaBlock(features[0] * 2)
        self.conv2 = nn.Sequential(
            nn.Conv3d(features[0] * 2, features[0], kernel_size=3, padding=1),
            nn.InstanceNorm3d(features[0]),
            nn.LeakyReLU(inplace=True)
        )

        # Output layers
        self.outc = nn.Sequential(
            nn.Conv3d(features[0], 16, kernel_size=3, padding=1),
            nn.InstanceNorm3d(16),
            nn.LeakyReLU(inplace=True),
            nn.Conv3d(16, out_channels, kernel_size=1),
            nn.Sigmoid()
        )

    def forward(self, x):
        # Encoder path
        x1 = self.inc(x)

        x2 = self.down1(x1)
        x2 = self.mamba1(x2)

        x3 = self.down2(x2)
        x3 = self.mamba2(x3)

        # Bottleneck
        x3 = self.bottleneck(x3)

        # Decoder path with skip connections
        x = self.up1(x3)
        # Ensure sizes match
        if x.shape[2:] != x2.shape[2:]:
            x = F.interpolate(x, size=x2.shape[2:], mode='nearest')
        x = torch.cat([x, x2], dim=1)
        x = self.up_mamba1(x)
        x = self.conv1(x)

        x = self.up2(x)
        # Ensure sizes match
        if x.shape[2:] != x1.shape[2:]:
            x = F.interpolate(x, size=x1.shape[2:], mode='nearest')
        x = torch.cat([x, x1], dim=1)
        x = self.up_mamba2(x)
        x = self.conv2(x)

        # Output layer
        x = self.outc(x)
        return x