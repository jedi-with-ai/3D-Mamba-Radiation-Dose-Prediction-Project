import numpy as np
import os


def calculate_metrics(pred_path, gt_path, struct_mask_path, ptv_name, prescription_dose):
    pred = np.load(pred_path)
    gt = np.load(gt_path)
    struct_dict = np.load(struct_mask_path, allow_pickle=True).item()

    if ptv_name not in struct_dict:
        return None  # skip if PTV missing

    mask = struct_dict[ptv_name].astype(bool)
    if mask.sum() == 0:
        return None  # skip if empty mask

    pred_in_mask = pred[mask]
    gt_in_mask = gt[mask]

    # 1️⃣ Dose Score (MAE)
    dose_score = np.mean(np.abs(pred_in_mask - gt_in_mask))

    # 2️⃣ DVH Score (% diff in mean dose)
    pred_mean = pred_in_mask.mean()
    gt_mean = gt_in_mask.mean()
    dvh_score = 100 * np.abs(pred_mean - gt_mean) / (gt_mean + 1e-8)

    # 3️⃣ HI (D2% - D98%) / prescription
    pred_sorted = np.sort(pred_in_mask)
    D2 = np.percentile(pred_sorted, 98)
    D98 = np.percentile(pred_sorted, 2)
    hi = (D2 - D98) / prescription_dose

    return dose_score, dvh_score, hi


def evaluate_model(pred_folder, gt_folder, output_file=None):
    ptv_names = {
        'PTV70': 70,
        'PTV63': 63,
        'PTV56': 56
    }

    all_metrics = {name: [] for name in ptv_names}

    # Get patient IDs by stripping ".npy"
    patient_ids = [f.replace('.npy', '') for f in os.listdir(pred_folder) if f.endswith('.npy')]

    for pid in patient_ids:
        pred_file = os.path.join(pred_folder, f'{pid}.npy')
        gt_file = os.path.join(gt_folder, pid, 'dose.npy')
        struct_file = os.path.join(gt_folder, pid, 'structure_masks.npy')

        if not os.path.exists(gt_file) or not os.path.exists(struct_file):
            print(f"Skipping {pid}: missing gt or structure_masks")
            continue

        for ptv_name, prescription in ptv_names.items():
            metrics = calculate_metrics(pred_file, gt_file, struct_file, ptv_name, prescription)
            if metrics is not None:
                all_metrics[ptv_name].append(metrics)
            else:
                print(f"{pid}: missing or empty mask for {ptv_name}")

    # Aggregate results
    results = {}
    for ptv_name in ptv_names:
        data = np.array(all_metrics[ptv_name])
        if len(data) == 0:
            print(f"\nNo valid data for {ptv_name}")
            continue

        dose_scores = data[:,0]
        dvh_scores = data[:,1]
        his = data[:,2]

        print(f"\n📊 Metrics for {ptv_name}:")
        print(f"  Dose Score: {dose_scores.mean():.4f} ± {dose_scores.std():.4f}")
        print(f"  DVH Score: {dvh_scores.mean():.2f}% ± {dvh_scores.std():.2f}%")
        print(f"  HI: {his.mean():.4f} ± {his.std():.4f}")
        
        results[ptv_name] = {
            'dose_score': (dose_scores.mean(), dose_scores.std()),
            'dvh_score': (dvh_scores.mean(), dvh_scores.std()),
            'hi': (his.mean(), his.std())
        }
    
    return results