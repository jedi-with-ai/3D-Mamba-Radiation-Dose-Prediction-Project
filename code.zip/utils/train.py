import torch
from torch.utils.data import DataLoader
from models.loss import DVHFocusedLoss


def train_model(model, dataset, batch_size=1, epochs=10, lr=3e-4, device='cuda'):
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, num_workers=0)
    model = model.to(device)

    # Loss and optimizer
    criterion = DVHFocusedLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    # Tracking best model
    best_loss = float('inf')

    for epoch in range(epochs):
        model.train()
        running_loss = 0.0

        for i, (inputs, targets, ptv_masks, oar_masks, _) in enumerate(dataloader):
            # Move data to device
            inputs = inputs.to(device)
            targets = targets.to(device)
            ptv_masks = ptv_masks.to(device)
            oar_masks = oar_masks.to(device)

            # Forward pass
            outputs = model(inputs)
            loss = criterion(outputs, targets, ptv_masks, oar_masks)

            # Backward and optimize
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

            # Print progress
            if (i + 1) % 5 == 0:
                print(f'Epoch [{epoch+1}/{epochs}], Step [{i+1}/{len(dataloader)}], Loss: {loss.item():.6f}')

        # Calculate average loss
        epoch_loss = running_loss / len(dataloader)
        print(f'Epoch [{epoch+1}/{epochs}], Loss: {epoch_loss:.6f}')

        # Save best model
        if epoch_loss < best_loss:
            best_loss = epoch_loss
            torch.save(model.state_dict(), 'best_mamba_model.pth')
            print(f'Best model saved with loss: {best_loss:.6f}')

    print('Training finished!')