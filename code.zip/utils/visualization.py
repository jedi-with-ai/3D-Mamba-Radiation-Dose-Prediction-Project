import torch
import numpy as np
import matplotlib.pyplot as plt
import os


def visualize_prediction(model, dataset, patient_idx=0, z_slice=64, device='cuda'):
    # Load data
    inputs, targets, ptv_masks, oar_masks, patient_id = dataset[patient_idx]
    inputs = inputs.unsqueeze(0).to(device)

    # Get CT slice and ground truth dose
    ct_slice = inputs[0, 0, z_slice].cpu().numpy()
    gt_slice = targets[0, z_slice].numpy()

    # Get model prediction
    model.eval()
    with torch.no_grad():
        outputs = model(inputs)
        pred_slice = outputs[0, 0, z_slice].cpu().numpy()

    # Print stats
    print(f"Patient: {patient_id}, Slice: {z_slice}")
    print(f"Ground Truth - Min: {gt_slice.min():.4f}, Max: {gt_slice.max():.4f}")
    print(f"Prediction - Min: {pred_slice.min():.4f}, Max: {pred_slice.max():.4f}")

    # Visualize results
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))

    # CT slice
    axes[0].imshow(ct_slice, cmap='gray')
    axes[0].set_title('CT Slice')
    axes[0].axis('off')

    # Ground truth dose
    im1 = axes[1].imshow(gt_slice, cmap='jet', vmin=0, vmax=1.0)
    axes[1].set_title('Ground Truth Dose')
    axes[1].axis('off')
    plt.colorbar(im1, ax=axes[1], fraction=0.046, pad=0.04)

    # Predicted dose
    im2 = axes[2].imshow(pred_slice, cmap='jet', vmin=0, vmax=1.0)
    axes[2].set_title('Predicted Dose')
    axes[2].axis('off')
    plt.colorbar(im2, ax=axes[2], fraction=0.046, pad=0.04)

    plt.tight_layout()
    plt.savefig(f'dose_comparison_{patient_id}.png', dpi=300, bbox_inches='tight')
    plt.show()

    # Also show dose overlay on CT
    fig, axes = plt.subplots(1, 2, figsize=(12, 6))

    axes[0].imshow(ct_slice, cmap='gray')
    gt_overlay = axes[0].imshow(gt_slice, cmap='jet', alpha=0.6, vmin=0, vmax=1.0)
    axes[0].set_title('Ground Truth Dose over CT')
    axes[0].axis('off')
    plt.colorbar(gt_overlay, ax=axes[0], fraction=0.046, pad=0.04)

    axes[1].imshow(ct_slice, cmap='gray')
    pred_overlay = axes[1].imshow(pred_slice, cmap='jet', alpha=0.6, vmin=0, vmax=1.0)
    axes[1].set_title('Predicted Dose over CT')
    axes[1].axis('off')
    plt.colorbar(pred_overlay, ax=axes[1], fraction=0.046, pad=0.04)

    plt.tight_layout()
    plt.savefig(f'dose_overlay_{patient_id}.png', dpi=300, bbox_inches='tight')
    plt.show()


def visualize_test_prediction(pred_path, test_dir, z_slice=64):
    # Extract patient ID from prediction filename
    pid = os.path.basename(pred_path).split('.')[0]  # Extracts 'pt_241' from the filename
    
    # Construct path to corresponding CT file in the patient's folder
    ct_path = os.path.join(test_dir, pid, "ct.npy")
    
    # Now load the files
    try:
        pred = np.load(pred_path)
        ct = np.load(ct_path)
        
        ct_slice = ct[z_slice]
        pred_slice = pred[z_slice]
        
        plt.figure(figsize=(12,6))
        plt.subplot(1,2,1)
        plt.imshow(ct_slice, cmap='gray')
        plt.title(f"CT Slice - {pid}")
        plt.axis('off')
        
        plt.subplot(1,2,2)
        plt.imshow(ct_slice, cmap='gray')
        overlay = plt.imshow(pred_slice, cmap='jet', alpha=0.6, vmin=0, vmax=1.0)
        plt.title(f"Predicted Dose - {pid}")
        plt.axis('off')
        plt.colorbar(overlay, fraction=0.046, pad=0.04)
        
        plt.tight_layout()
        plt.show()
        print(f"Successfully visualized prediction for {pid}")
    except Exception as e:
        print(f"Error visualizing {pid}: {e}")
        print(f"Checking if files exist:")
        print(f"Prediction file exists: {os.path.exists(pred_path)}")
        print(f"CT file exists: {os.path.exists(ct_path)}")